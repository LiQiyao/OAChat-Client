package com.example.trt.pptalk.resolver;

/**
 * Created by Administrator on 2017/12/1.
 */
public interface DataResolver {
    void resolve(String jsonMessage);
}
