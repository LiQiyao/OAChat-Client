package com.example.trt.pptalk.resolver.impl;


import android.os.Message;

import com.example.trt.pptalk.dto.MessageDTO;
import com.example.trt.pptalk.dto.data.AddFriendRequestDTO;
import com.example.trt.pptalk.resolver.DataResolver;
import com.example.trt.pptalk.util.GsonUtil;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;

/**
 * Created by Administrator on 2017/12/1.
 */
public class AddFriendRequestDTOResolver implements DataResolver {

    @Override
    public void resolve(String jsonMessage) {
        Type objectType = new TypeToken<MessageDTO<AddFriendRequestDTO>>(){}.getType();
        MessageDTO<AddFriendRequestDTO> message = GsonUtil.getInstance().fromJson(jsonMessage, objectType);
        AddFriendRequestDTO addFriendRequestDTO = message.getData();
    }
}
