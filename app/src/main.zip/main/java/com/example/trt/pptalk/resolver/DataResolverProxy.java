package com.example.trt.pptalk.resolver;



import com.example.trt.pptalk.dto.MessageDTO;
import com.example.trt.pptalk.resolver.impl.AddFriendRequestDTOResolver;
import com.example.trt.pptalk.resolver.impl.AddFriendSuccessDTOResolver;
import com.example.trt.pptalk.resolver.impl.ChatLogResolver;
import com.example.trt.pptalk.resolver.impl.OnlineDTOResolver;
import com.example.trt.pptalk.util.GsonUtil;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by Administrator on 2017/12/1.
 */
public class DataResolverProxy {

    private static final DataResolverProxy INSTANCE = new DataResolverProxy();

    public final ConcurrentHashMap<String, DataResolver> RESOLVER_MAP = new ConcurrentHashMap<>();

    private DataResolverProxy(){
        RESOLVER_MAP.put("chatLog", new ChatLogResolver());
        RESOLVER_MAP.put("onlineDTO", new OnlineDTOResolver());
        RESOLVER_MAP.put("addFriendSuccessDTO", new AddFriendSuccessDTOResolver());
        RESOLVER_MAP.put("addFriendRequestDTO", new AddFriendRequestDTOResolver());
    }

    public static DataResolverProxy getInstance(){
        return INSTANCE;
    }



    public void doAction(String jsonMessage){
        MessageDTO messageDTO = GsonUtil.getInstance().fromJson(jsonMessage, MessageDTO.class);
        RESOLVER_MAP.get(messageDTO.getDataName()).resolve(jsonMessage);
    }
}
