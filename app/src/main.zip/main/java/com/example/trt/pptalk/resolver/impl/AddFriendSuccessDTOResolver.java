package com.example.trt.pptalk.resolver.impl;



import com.example.trt.pptalk.dto.MessageDTO;
import com.example.trt.pptalk.dto.data.AddFriendSuccessDTO;
import com.example.trt.pptalk.resolver.DataResolver;
import com.example.trt.pptalk.util.GsonUtil;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;

/**
 * Created by Administrator on 2017/12/1.
 */
public class AddFriendSuccessDTOResolver implements DataResolver {
    @Override
    public void resolve(String jsonMessage) {
        Type objectType = new TypeToken<MessageDTO<AddFriendSuccessDTO>>(){}.getType();
        MessageDTO<AddFriendSuccessDTO> message = GsonUtil.getInstance().fromJson(jsonMessage, objectType);
        AddFriendSuccessDTO addFriendSuccessDTO = message.getData();
    }
}
