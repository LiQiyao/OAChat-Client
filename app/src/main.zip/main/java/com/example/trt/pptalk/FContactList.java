package com.example.trt.pptalk;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ExpandableListView;


/**
 * Created by Trt on 2017/11/26.
 */

public class FContactList extends android.support.v4.app.Fragment {
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /* 1.1 创建一个adapter实例*/
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        View view=inflater.inflate(R.layout.f_contact_list,container,false);

        MyExpandableListViewAdapter adapter = new MyExpandableListViewAdapter(getActivity());

        /* 1. 设置适配器*/
        ExpandableListView myExpandableListView= (ExpandableListView) view.findViewById(R.id.elv);
        myExpandableListView.setAdapter(adapter);
        myExpandableListView.setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @Override
            public boolean onChildClick(ExpandableListView parent, View v, int groupPosition, int childPosition, long id) {
                    Intent intent=new Intent(getActivity(),Chat.class);
                    startActivity(intent);
                return true;
            }
        });
        return view;
    }
}


