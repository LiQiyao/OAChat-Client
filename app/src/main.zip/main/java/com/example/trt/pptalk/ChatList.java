package com.example.trt.pptalk;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

public class ChatList extends Activity {
    private String[] name=new String[]{
            "请求","安全","按时"
    };
    private String[] lastMsg=new String[]{
            "zzzzqqqq","czcczzzasdd","qqqwezcz"
    };
    private int[] headIds=new int[]{
            R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_list);
        List<Map<String,Object>> ListItems=new ArrayList<Map<String,Object>>();
        for(int i=0;i<name.length;i++){
            Map<String, Object> listItem= new HashMap<String,Object>();
            listItem.put("header",headIds[i]);
            listItem.put("lastMsg",lastMsg[i]);
            listItem.put("name",name[i]);
            ListItems.add(listItem);
        }
        SimpleAdapter simpleAdapter=new SimpleAdapter(this,ListItems,R.layout.simple_item,new String[]{"name","lastMsg","header"},new int[]{R.id.name,R.id.lastMsg,R.id.header});
        ListView listView= (ListView) findViewById(R.id.chat_list);
        listView.setAdapter(simpleAdapter);
        RelativeLayout contacts= (RelativeLayout) findViewById(R.id.contacts);
        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ChatList.this,ContactList.class);
                startActivity(intent);
                finish();
            }
        });
    }

}
