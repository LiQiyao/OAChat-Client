package com.example.trt.pptalk.dto.data;

/**
 * @author Lee
 * @date 2017/11/30
 */
public class OnlineDTO {
}
