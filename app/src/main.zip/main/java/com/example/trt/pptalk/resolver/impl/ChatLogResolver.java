package com.example.trt.pptalk.resolver.impl;


import android.os.Handler;
import android.os.Message;

import com.example.trt.pptalk.dto.MessageDTO;
import com.example.trt.pptalk.dto.data.ChatLog;
import com.example.trt.pptalk.resolver.DataResolver;
import com.example.trt.pptalk.util.GsonUtil;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;

/**
 * Created by Administrator on 2017/12/1.
 */
public class ChatLogResolver implements DataResolver {
Handler revHandle;
    @Override
    public void resolve(String jsonMessage) {
        Type objectType = new TypeToken<MessageDTO<ChatLog>>(){}.getType();
        MessageDTO<ChatLog> message = GsonUtil.getInstance().fromJson(jsonMessage, objectType);
        ChatLog chatLog = message.getData();
        Message msg=new Message();
        msg.what=0x789;
        msg.obj=chatLog;
        revHandle.sendMessage(msg);
        //TODO 在屏幕上显示

    }
}
