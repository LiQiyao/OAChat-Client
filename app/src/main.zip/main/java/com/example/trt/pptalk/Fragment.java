package com.example.trt.pptalk;

import android.app.Activity;
import android.app.FragmentManager;
import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

public class Fragment extends FragmentActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fragment);
        RelativeLayout message= (RelativeLayout) findViewById(R.id.message);
        RelativeLayout contacts= (RelativeLayout) findViewById(R.id.contacts);
        ChangeTab(0);
        //点击消息按钮
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                ImageView imageView= (ImageView) findViewById(R.id.message_pic);
//                imageView.setImageResource(R.mipmap.icon_message_press);
//                android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
//                FragmentTransaction transaction = manager.beginTransaction();
//                Toast.makeText(Fragment.this,"111",Toast.LENGTH_LONG).show();
//                FChatList fragment=new FChatList();
//                transaction.replace(R.id.container, fragment);
//                transaction.commit();
                ChangeTab(0);
            }
        });
        //点击联系人按钮
        contacts.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
//                android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
//                FragmentTransaction transaction = manager.beginTransaction();
//                Toast.makeText(Fragment.this,"222",Toast.LENGTH_LONG).show();
//                FContactList fragment= new FContactList();
//                transaction.replace(R.id.container, fragment);
//                transaction.commit();
                ChangeTab(1);
            }
        });
    }
    public void ChangeTab(int i){
        ImageView message= (ImageView) findViewById(R.id.message_pic);
        ImageView contacts= (ImageView) findViewById(R.id.contacts_pic);
        TextView tag= (TextView) findViewById(R.id.tab);
        android.support.v4.app.FragmentManager manager = getSupportFragmentManager();
        FragmentTransaction transaction = manager.beginTransaction();
        if(i==0){
            message.setImageResource(R.mipmap.icon_message_press);
            contacts.setImageResource(R.mipmap.icon_contact_normal);
            tag.setText("消息");
            FChatList fragment=new FChatList();
            transaction.replace(R.id.container, fragment);
            transaction.commit();
        }
        if(i==1){
            message.setImageResource(R.mipmap.icon_message_normal);
            contacts.setImageResource(R.mipmap.icon_contact_press);
            tag.setText("联系人");
            FContactList fragment= new FContactList();
            transaction.replace(R.id.container, fragment);
            transaction.commit();
        }
    }
}
