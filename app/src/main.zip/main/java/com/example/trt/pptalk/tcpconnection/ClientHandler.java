package com.example.trt.pptalk.tcpconnection;

import android.content.Context;
import android.util.Log;

import com.example.trt.pptalk.resolver.DataResolverProxy;

import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;

/**
 * Created by Administrator on 2017/11/27.
 * @author lee
 */

public class ClientHandler extends SimpleChannelInboundHandler<String> {

    private Context context;

    @Override
    protected void channelRead0(ChannelHandlerContext ctx, String msg)
            throws Exception {
        Log.d("MyHelloClientHandler", "channelRead0->msg=" + msg);

        DataResolverProxy.getInstance().doAction(msg);
        /*Message message = new Message();
        message.what = MainActivity.MSG_REC;
        message.obj = msg;
        MainActivity.mHandler.sendMessage(message);*/
        //Toast.makeText(context, msg, Toast.LENGTH_SHORT).show();
    }

    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Client active");
        super.channelActive(ctx);
    }

    @Override
    public void channelInactive(ChannelHandlerContext ctx) throws Exception {
        System.out.println("Client close ");
        super.channelInactive(ctx);
    }

}