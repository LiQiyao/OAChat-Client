package com.example.trt.pptalk.tcpconnection;

import android.content.Context;


import com.example.trt.pptalk.dto.MessageDTO;
import com.example.trt.pptalk.util.GsonUtil;

import io.netty.bootstrap.Bootstrap;
import io.netty.channel.Channel;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelOption;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.nio.NioSocketChannel;

import java.net.InetSocketAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * @author Lee
 * @date 2017/12/1
 */
public class TCPClient {

    private static TCPClient INSTANCE = new TCPClient();

    private TCPClient(){}

    public static TCPClient getInstance(){
        return INSTANCE;
    }

    private NioEventLoopGroup group;

    private int port = 52621;

    private String ip = "";

    private Channel channel;

    private Context context;

    public void connect(final Context context) {
        new Thread() {
            @Override
            public void run() {
                group = new NioEventLoopGroup();
                try {
                    // Client服务启动器 3.x的ClientBootstrap
                    // 改为Bootstrap，且构造函数变化很大，这里用无参构造。
                    Bootstrap bootstrap = new Bootstrap();
                    // 指定EventLoopGroup
                    bootstrap.group(group);
                    // 指定channel类型
                    bootstrap.channel(NioSocketChannel.class);
                    // 指定Handler
                    bootstrap
                            .handler(new ClientInitializer());
                    //如果没有数据，这个可以注释看看
                    bootstrap.option(ChannelOption.SO_KEEPALIVE, true);
                    bootstrap.option(ChannelOption.TCP_NODELAY, true);
                    // 连接到本地的7878端口的服务端
                    ChannelFuture channelFuture  = bootstrap.connect(new InetSocketAddress(ip, port));
                    channel = channelFuture.sync().channel();
                } catch (Exception e) {
                    e.printStackTrace();
                } finally {
                    group.shutdownGracefully();
                }
            }
        }.start();
    }

    public void disConnect(){
        group.shutdownGracefully();
    }

    public void sendMessage(MessageDTO messageDTO){
        channel.writeAndFlush(GsonUtil.getInstance().toJson(messageDTO));
    }
}
