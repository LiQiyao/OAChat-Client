package com.example.trt.pptalk;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.Button;
import android.widget.ExpandableListView;
import android.widget.RelativeLayout;

/**
 * Created by Trt on 2017/11/25.
 */

public class ContactList extends Activity {
    private ExpandableListView expandableListView ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_contact_list);
        expandableListView = (ExpandableListView) findViewById(R.id.elv);

        /* 1.1 创建一个adapter实例*/
        MyExpandableListViewAdapter adapter = new MyExpandableListViewAdapter(this);

        /* 1. 设置适配器*/
        expandableListView.setAdapter(adapter);
        RelativeLayout message= (RelativeLayout) findViewById(R.id.message);
        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(ContactList.this,ChatList.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
