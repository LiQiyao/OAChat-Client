package com.example.trt.pptalk;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.example.trt.pptalk.dto.data.ChatLog;
import com.example.trt.pptalk.entity.PersonChat;

import java.util.List;

/**
 * Created by Trt on 2017/11/28.
 */

public class ChatAdapter extends BaseAdapter {
    private Long myId=1L;
    private Context context;
    private List<ChatLog> chatList;
    public ChatAdapter(Context context, List<ChatLog> chatList) {
        super();
        this.context = context;
        this.chatList = chatList;
    }

    @Override
    public boolean isEnabled(int position) {
        return false;
    }

    @Override
    public int getCount() {
        return chatList.size();
    }

    @Override
    public Object getItem(int position) {
        return chatList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        ChatLog chatLog=chatList.get(position);
        if(chatLog.getSenderId()==myId){
            view=View.inflate(context, R.layout.item_chat_right,
                    null);
            ((TextView)view.findViewById(R.id.tv_me_chat_message)).setText(chatLog.getContent());
        }
        else{
            view=View.inflate(context,R.layout.item_chat_left,null);
            ((TextView)view.findViewById(R.id.tv_chat_me_message)).setText(chatLog.getContent());
        }
        return view;
    }
}
