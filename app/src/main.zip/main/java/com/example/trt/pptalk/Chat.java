package com.example.trt.pptalk;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.trt.pptalk.dto.data.ChatLog;
import com.example.trt.pptalk.entity.PersonChat;

import java.util.ArrayList;
import java.util.List;

public class Chat extends AppCompatActivity {
    private Long myId = 1L;
    private ChatAdapter chatAdapter;
    private ListView lv_chat_dialog;
    private List<ChatLog> chatLogs = new ArrayList<ChatLog>();
    private Handler handler = new Handler() {
        public void handleMessage(android.os.Message msg) {
            int what = msg.what;
            switch (what) {
                case 1:
                    /**
                     * ListView条目控制在最后一行
                     */
                    lv_chat_dialog.setSelection(chatLogs.size());
                    break;

                default:
                    break;
            }
        };
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        for (int i = 0; i <= 3; i++) {
            ChatLog chatLog = new ChatLog();
            chatLog.setSenderId(myId);
            chatLogs.add(chatLog);
        }
        lv_chat_dialog = (ListView) findViewById(R.id.lv_chat_dialog);
        final Button btn_chat_message_send = (Button) findViewById(R.id.btn_chat_message_send);
        final EditText et_chat_message = (EditText) findViewById(R.id.et_chat_message);
        final ImageView back= (ImageView) findViewById(R.id.back);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(Chat.this,Fragment.class);
                startActivity(intent);
            }
        });
        /**
         *setAdapter
         */
        chatAdapter = new ChatAdapter(this, chatLogs);
        lv_chat_dialog.setAdapter(chatAdapter);
        et_chat_message.addTextChangedListener(new TextWatcher() {

            // 第二个执行
            @Override
            public void onTextChanged(CharSequence s, int start, int before,int count) {
            }

            // 第一个执行
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,int after) {
            }

            // 第三个执行
            @Override
            public void afterTextChanged(Editable s) { // Edittext中实时的内容
                if(s.length()>0){
                    btn_chat_message_send.setBackgroundColor(Color.parseColor("#12B7F5"));
                }
                else{
                    btn_chat_message_send.setBackgroundColor(Color.parseColor("#D4D4D4"));
                }
            }
        });
        Handler revHandler = new Handler() {
            ChatLog newChatLog;
            @Override
            public void handleMessage(Message msg) {
                if (msg.what == 0x789) {
                    newChatLog = (ChatLog) msg.obj;
                    chatLogs.add(newChatLog);
                    chatAdapter.notifyDataSetChanged();
                    handler.sendEmptyMessage(1);
                }
            }
        };
        /**
         * 发送按钮的点击事件
         */
        btn_chat_message_send.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                if (TextUtils.isEmpty(et_chat_message.getText().toString())) {
                    Toast.makeText(Chat.this, "发送内容不能为空",Toast.LENGTH_LONG).show();
                    return;
                }
                ChatLog chatLog = new ChatLog();
                //代表自己发送
                chatLog.setSenderId(myId);
                //得到发送内容
                chatLog.setContent(et_chat_message.getText().toString());
                //加入集合
                chatLogs.add(chatLog);
                //清空输入框
                et_chat_message.setText("");
                //刷新ListView
                chatAdapter.notifyDataSetChanged();
                handler.sendEmptyMessage(1);
            }
        });
    }

}
