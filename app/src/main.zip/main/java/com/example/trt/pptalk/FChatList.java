package com.example.trt.pptalk;

import android.app.Fragment;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Trt on 2017/11/26.
 */

public class FChatList extends android.support.v4.app.Fragment {
    private String[] name=new String[]{
            "请求","安全","按时"
    };
    private String[] lastMsg=new String[]{
            "zzzzqqqq","czcczzzasdd","qqqwezcz"
    };
    private int[] headIds=new int[]{
            R.mipmap.ic_launcher,R.mipmap.ic_launcher,R.mipmap.ic_launcher
    };
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {
        List<Map<String,Object>> ListItems=new ArrayList<Map<String,Object>>();
        for(int i=0;i<name.length;i++){
            Map<String, Object> listItem= new HashMap<String,Object>();
            listItem.put("header",headIds[i]);
            listItem.put("lastMsg",lastMsg[i]);
            listItem.put("name",name[i]);
            ListItems.add(listItem);
        }
        SimpleAdapter simpleAdapter=new SimpleAdapter(getActivity(),ListItems,R.layout.simple_item,new String[]{"name","lastMsg","header"},new int[]{R.id.name,R.id.lastMsg,R.id.header});
        View view=inflater.inflate(R.layout.f_chat_list,container,false);
        ListView chatLsit= (ListView) view.findViewById(R.id.chat_list);
        chatLsit.setAdapter(simpleAdapter);
        chatLsit.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent=new Intent(getActivity(),Chat.class);
                startActivity(intent);
            }
        });

        return view;
    }
}


